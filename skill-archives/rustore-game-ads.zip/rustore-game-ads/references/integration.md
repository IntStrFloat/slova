# Провайдер и официальная интеграция

## Стартовая карта источников

Проверена 2026-09-18; при использовании открывай текущую документацию заново:

- [Yandex Android quick start](https://ads.yandex.com/helpcenter/en/dev/android/quick-start).
- [Yandex React Native quick start](https://ads.yandex.com/helpcenter/en/dev/react-native/quick-start).
- [Android rewarded](https://ads.yandex.com/helpcenter/en/dev/android/rewarded).
- [Android interstitial](https://ads.yandex.com/helpcenter/en/dev/android/interstitial).
- [Android форматы](https://ads.yandex.com/helpcenter/en/dev/android/formats): перейди к актуальному adaptive sticky banner.
- [React Native rewarded](https://ads.yandex.com/helpcenter/en/dev/react-native/rewarded): из навигации открывай sticky banner, interstitial, privacy, changelog, тестовые блоки и ILRD.
- [Возрастные ограничения данных SDK](https://ads.yandex.com/helpcenter/en/dev/android/coppa): применимость устанавливай по аудитории/территориям, не автоматически для любой игры.
- [Требования RuStore](https://www.rustore.ru/help/developers/publishing-and-verifying-apps/requirement-apps), [публикация/декларация](https://www.rustore.ru/help/developers/publishing-and-verifying-apps/app-publication).

Официальная RN-страница на дату проверки ссылается на пакет `yandex-mobile-ads`, описывает Android-настройки, auto-init, privacy до init и проверку интеграции логами. Это не доказательство совместимости пакета с конкретными RN/Expo или New Architecture. Документация отдельных major-версий отличается — не смешивай API версий 7 и 8.

В Android rewarded-документации событие `onRewarded` относится к earned reward. Точное имя события обёртки и порядок callback проверь по её версии/примеру; не копируй название Kotlin listener в JS API без проверки.

В официальных Yandex-примерах используются `demo-banner-yandex`, `demo-interstitial-yandex`, `demo-rewarded-yandex`. Перепроверь их поддержку для выбранного SDK и никогда не выдавай demo ID за производственный блок.

Если провайдер иной, замени карту его первичными инструкциями banner/interstitial/rewarded, testing, privacy, release notes и server verification при наличии. Не переводись на Yandex вопреки указанной сети.

## Матрица конфигурации

Отделяй:

- SDK/пакеты: точные версии и подтверждённая совместимость зависимостей/адаптеров.
- Публичные ad unit/app ID: источник, среда, формат и привязка к Android-приложению.
- Секреты кабинета/серверной проверки: только сервер/локальная защищённая конфигурация, вне APK и git.
- Политика показов: разрешённые экраны, cooldown, лимиты, first-session grace, отключение и привилегии no-ads.
- Каталог наград: offer ID, товар/количество, контекст, применимость, лимиты и сохранение.

Запрос/показ может завершиться no-fill даже при корректной конфигурации. Классифицируй ошибки по документации; не трактуй любую ошибку загрузки как неверный SDK и не ретраить бесконечно. Используй ограниченный backoff и возобновление по разрешённым триггерам; не устраивай цикл load в error-listener.

Версии закрепи, а конфигурацию проверь в release. Production-профиль запрещает demo/пустые ID для включённых размещений. Явно выключенный формат отличай от случайно отсутствующей настройки.

## Expo/RN и native lifecycle

Сохрани текущий Android-native код и способы генерации. Для native-моста нужна реальная UI-Activity; события проходятся одним маршрутом, отписываются и не выдаются повторно при повторном mount. Полноэкранный ad object используй по documented lifetime; после потребления создавай новую загрузку.

Локальный ID попытки служит для связи callbacks и идемпотентности, не является подписью провайдера. Если wrapper не передаёт provider impression/transaction ID, не выдумывай его из request ID.

Настрой pause/resume игрового времени, звука и ввода по реальному lifecycle показа. Ошибка/закрытие восстанавливают игровое состояние; возвращение из клика во внешнее приложение не запускает второй fullscreen автоматически.

Автоматическая инициализация может произойти раньше JS. Если требуется настройка до запросов, применяй документированный native init/control path, а не только consent-dialog в первом React render.
